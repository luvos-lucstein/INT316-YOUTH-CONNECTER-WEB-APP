/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Morok
 */
@Entity
public class Activities implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "YouthMemberID")
    private Long id;
    private String activity;
    private String description;
    @Temporal(TemporalType.DATE)
    private Date creationDate;
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "youth_member_fk", nullable = false)
    private YouthMember youth;

    public Activities() {
    }

    public Activities(Long id, String activity, String description, Date creationDate, YouthMember youth) {
        this.id = id;
        this.activity = activity;
        this.description = description;
        this.creationDate = creationDate;
        this.youth = youth;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public YouthMember getYouth() {
        return youth;
    }

    public void setYouth(YouthMember youth) {
        this.youth = youth;
    }
    
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Activities)) {
            return false;
        }
        Activities other = (Activities) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Activities[ id=" + id + " ]";
    }
    
}
