/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import entities.Activities;
import entities.ActivitiesFacadeLocal;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Morok
 */
public class GroupYouthServlet extends HttpServlet {
  
    @EJB
    ActivitiesFacadeLocal afl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Activities> activities = afl.findAll();
        
        // Create new lists for each activity group
        List<Activities> musicActivities = new ArrayList<>();
        List<Activities> sportsActivities = new ArrayList<>();
        List<Activities> studyActivities = new ArrayList<>();
        List<Activities> techActivities = new ArrayList<>();
        List<Activities> gamingActivities = new ArrayList<>();
        List<Activities> artActivities = new ArrayList<>();
        List<Activities> otherActivities = new ArrayList<>();
        
        // Group the activities based on their activity type
    for (Activities activity : activities) {
        String activityType = activity.getActivity().toLowerCase();
        switch (activityType) {
            case "music":
                musicActivities.add(activity);
                break;
            case "sports":
                sportsActivities.add(activity);
                break;
            case "study":
                studyActivities.add(activity);
                break;
            case "tech":
                techActivities.add(activity);
                break;
            case "gaming":
                gamingActivities.add(activity);
                break;
            case "art":
                artActivities.add(activity);
                break;
            default:
                otherActivities.add(activity);
                break;
        }
    }
    
        // Example: Set them as attributes if you want to forward them to a JSP or use them later
        request.setAttribute("musicActivities", musicActivities);
        request.setAttribute("sportsActivities", sportsActivities);
        request.setAttribute("studyActivities", studyActivities);
        request.setAttribute("techActivities", techActivities);
        request.setAttribute("gamingActivities", gamingActivities);
        request.setAttribute("artActivities", artActivities);
        request.setAttribute("otherActivities", otherActivities);
    
        RequestDispatcher disp = request.getRequestDispatcher("grouped_youth_outcome.jsp");
        disp.forward(request, response);
    }
}
