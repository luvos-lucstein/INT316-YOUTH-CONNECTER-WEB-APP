
package servlets;

import entities.Activities;
import entities.ActivitiesFacadeLocal;
import entities.YouthMember;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterActivityServlet extends HttpServlet {
 
    @EJB
    private ActivitiesFacadeLocal afl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
        Long activityID = Long.parseLong(request.getParameter("activityID"));
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        int age = Integer.parseInt(request.getParameter("age"));
        String gender = request.getParameter("gender");
        String dateStr = request.getParameter("date");

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date creationDate = dateFormat.parse(dateStr);

        String activity = request.getParameter("activity");
        String activityDescription = request.getParameter("activityDescription");

        // Validate inputs (optional, but safer)
        if(username == null || email == null || activity == null || activityDescription == null) {
            throw new ServletException("All fields are required.");
        }

        // Create and persist objects
        YouthMember youth = new YouthMember(username, gender, email, age);
        Activities activities = new Activities(activityID, activity, activityDescription, creationDate, youth);

        afl.create(activities);
        request.setAttribute("username", username);
        request.setAttribute("activityID", activityID);
        request.setAttribute("activity", activity);

        // Forward to outcome page
        RequestDispatcher disp = request.getRequestDispatcher("register_activity_outcome.jsp");
        disp.forward(request, response);

    } catch (ParseException | NumberFormatException ex) {
        Logger.getLogger(RegisterActivityServlet.class.getName()).log(Level.SEVERE, null, ex);
        throw new ServletException("Invalid input: " + ex.getMessage());
    }
    }
}
