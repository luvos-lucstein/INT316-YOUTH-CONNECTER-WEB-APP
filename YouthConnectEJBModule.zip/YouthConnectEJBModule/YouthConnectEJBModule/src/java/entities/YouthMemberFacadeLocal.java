/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Morok
 */
@Local
public interface YouthMemberFacadeLocal {

    void create(YouthMember youthMember);

    void edit(YouthMember youthMember);

    void remove(YouthMember youthMember);

    YouthMember find(Object id);

    List<YouthMember> findAll();

    List<YouthMember> findRange(int[] range);

    int count();
    
}
