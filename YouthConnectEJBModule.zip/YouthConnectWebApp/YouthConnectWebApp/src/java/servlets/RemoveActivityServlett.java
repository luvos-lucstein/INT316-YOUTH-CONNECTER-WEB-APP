package servlets;

import entities.Activities;
import entities.ActivitiesFacadeLocal;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Luvo
 */
public class RemoveActivityServlett extends HttpServlet {

    @EJB ActivitiesFacadeLocal afl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         
        try {
            String activityIDParam = request.getParameter("activityID");
            
            // Validate parameter
            if (activityIDParam == null || activityIDParam.isEmpty()) {
                request.setAttribute("error", "Activity ID is required");
                request.getRequestDispatcher("errorPage.jsp").forward(request, response);
                return;
            }
            
            Long activityID = Long.parseLong(activityIDParam);
            Activities activity = afl.find(activityID);
            
            // Check if activity exists
            if (activity == null) {
                request.setAttribute("error", "Activity not found with ID: " + activityID);
                request.getRequestDispatcher("errorPage.jsp").forward(request, response);
                return;
            }
            
            afl.remove(activity);
            request.setAttribute("activityId", activityID);
            request.getRequestDispatcher("register_activity_outcome.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            request.setAttribute("error", "Invalid Activity ID format");
            request.getRequestDispatcher("errorPage.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "Error removing activity: " + e.getMessage());
            request.getRequestDispatcher("errorPage.jsp").forward(request, response);
        }
    }
}
        
 
      