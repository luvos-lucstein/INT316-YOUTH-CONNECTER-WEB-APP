
package servlets;

import entities.Activities;
import entities.ActivitiesFacadeLocal;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetAllRegisteredYouthServlet extends HttpServlet {

    @EJB
    ActivitiesFacadeLocal afl;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Activities> activities = afl.findAll();
        
        request.setAttribute("activities", activities);
        
        RequestDispatcher disp = request.getRequestDispatcher("get_all_registered_youth_outcome.jsp");
        disp.forward(request, response);
    }
}
